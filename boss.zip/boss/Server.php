<?php

declare(strict_types=1);

namespace boss;

class Server
{
    public static function space()
    {

    }
}