<?php /*a:6:{s:42:"/www/wwwroot/boss/app/view/home/index.html";i:1738457294;s:42:"/www/wwwroot/boss/app/view/layout/app.html";i:1738457294;s:45:"/www/wwwroot/boss/app/view/layout/header.html";i:1738457294;s:48:"/www/wwwroot/boss/app/view/layout/_composer.html";i:1738493644;s:45:"/www/wwwroot/boss/app/view/layout/_emoji.html";i:1737851948;s:52:"/www/wwwroot/boss/app/view/layout/_list_twitter.html";i:1738457294;}*/ ?>
<!doctype html>
<html lang="zh-cn">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>首页</title>
    <link rel="stylesheet" href="/font/iconfont.css">
    <link rel="stylesheet" href="/css/bootstrap.css">
    <link rel="stylesheet" href="/css/twitter.css">
</head>

<body class="d-flex w-100">
    <header id="app-header" class="flex-column flex-grow-1 align-items-end" role="banner">
    <div class="header-wrap d-flex align-items-end">
        <div class="header-wrap d-flex flex-column px-2 position-fixed top-0 h-100 overflow-x-hidden overflow-y-auto">
            <div class="d-flex flex-column">
                <h1 class="app-logo p-3 mb-0" role="heading">
                    <a href="/"><img src="/img/logo.png" loading="lazy" alt=""></a>
                </h1>
                <nav class="app-nav d-flex flex-column" role="navigation">
                    <a href="/" class="app-link" data-active="home" title="主页">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-home"></i>
                            <div class="app-nav-text">主页</div>
                            <div class="unread-dot"></div>
                        </div>
                    </a>
                    <a class="app-link" href="/explore" data-active="explore" title="探索">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-search"></i>
                            <div class="app-nav-text">探索</div>
                        </div>
                    </a>
                    <a class="app-link" href="/notification" data-active="notifications" title="通知">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-notifications"></i>
                            <div class="app-nav-text">通知</div>
                            <div class="d-flex align-items-center unread-message ">1</div>
                        </div>
                    </a>
                    <a class="app-link" href="/message" data-active="message" title="私信">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-messages"></i>
                            <div class="app-nav-text">私信</div>
                        </div>
                    </a>
                    <a href="/fav" class="app-link" data-active="fav" title="收藏夹">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-fav"></i>
                            <div class="app-nav-text">收藏夹</div>
                        </div>
                    </a>
                    <!-- <a href="/tag" class="app-link" data-active="tag" title="标签">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-explore"></i>
                            <div class="app-nav-text">标签</div>
                        </div>
                    </a>
                    <a class="app-link" href="/reward" data-active="reward" title="奖励">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-present"></i>
                            <div class="app-nav-text">领金币</div>
                        </div>
                    </a>
                    <a class="app-link" href="/medal" data-active="medal" title="勋章">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-medal"></i>
                            <div class="app-nav-text">勋章</div>
                        </div>
                    </a>
                    <a class="app-link" href="/tool" data-active="tool" title="工具箱">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-work"></i>
                            <div class="app-nav-text">工具箱</div>
                        </div>
                    </a>
                    <a class="app-link" href="/lists" data-active="lists" title="列表">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-lists"></i>
                            <div class="app-nav-text">列表</div>
                        </div>
                    </a>
                    <a class="app-link" href="/message" data-active="message" title="消息">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-notifications"></i>
                            <div class="app-nav-text">消息</div>
                            <div class="unread-message">1</div>
                        </div>
                    </a>
                    <a class="app-link" href="/bbs" data-active="bbs" title="动态">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-topics"></i>
                            <div class="app-nav-text">动态</div>
                        </div>
                    </a> -->
                    <?php if(session('user_id')): ?>
                    <a class="app-link" href="/user/profile/<?php echo session('user_id'); ?>" data-active="user" title="个人资料">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-user"></i>
                            <div class="app-nav-text">个人资料</div>
                        </div>
                    </a>
                    <button type="button" id="createPost" class="btn btn-dark justify-content-center rounded-pill" data-bs-toggle="modal" data-bs-target="#js-createPostModal">发帖</button>
                    <!-- 小屏显示的发帖按钮 -->
                    <button type="button" class="btn btn-dark twteet-btn" data-bs-toggle="modal" data-bs-target="#js-createPostModal" title="发帖">
                        <div class="nav-item d-inline-flex justify-content-center">
                            <i class="iconfont icon-feather"></i>
                        </div>
                    </button>
                    <?php else: ?>
                    <a class="app-link" href="/login" data-active="user" title="登录">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-user"></i>
                            <div class="app-nav-text">登录</div>
                        </div>
                    </a>
                    <?php endif; ?>
                </nav>
            </div>
            <?php if(session('user_id')): ?>
            <div class="dropup mt-auto">
                <div class="d-flex align-items-center fs-15px account-switcher-btn" id="account-switcher-btn" data-bs-toggle="dropdown" aria-expanded="false">
                    <img class="avatar" src="<?php echo get_avatar(session('user_id')); ?>" loading="lazy" alt="">
                    <div class="d-flex flex-column lh-1 ms-2">
                        <div><?php echo session('username'); ?></div>
                    </div>
                    <div class="ms-auto">
                        <i class="iconfont icon-more fs-5"></i>
                    </div>
                </div>
                <div class="dropdown-menu">
                    <?php if(session('is_admin')): ?>
                    <a href="/admin" class="dropdown-item">
                        <i class="iconfont icon-set fs-5 me-2"></i>
                        <span>进入后台</span>
                    </a>
                    <hr class="dropdown-divider">
                    <?php endif; ?>
                    <a href="/auth/logout/<?php echo csrf_token(); ?>" class="dropdown-item">
                        <i class="iconfont icon-logout fs-5 me-2"></i>
                        <span>退出</span>
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</header>

<?php if(session('user_id')): ?>
<div class="modal fade" id="js-createPostModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-bottom-0">
                <h5 class="modal-title">发新帖</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Modal body text goes here.</p>
            </div>
            <div class="modal-footer border-top-0">
                <button type="button" class="btn btn-primary">发布</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

    
<main role="main" class="d-flex flex-grow-1">
    <div class="d-flex main-wrap justify-content-between min-vh-100">
        <div class="primary-col">
            <!-- 顶部导航条 -->
            <div class="breadcrumb d-flex justify-content-between align-items-center px-3 js-scroll">
                <a href="/login" class="btn btn-sm btn-icon only-on-sm" role="button">
                    <i class="iconfont icon-user"></i>
                </a>
                <h2 class="fs-18px fw-bold cursor-pointer js-top">主页</h2>
                <div class="dropdown">
                    <button class="btn btn-sm btn-icon" type="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="iconfont icon-magic"></i></button>
                    <div class="dropdown-menu animated-dropdown dropdown-menu-end fs-15px">
                        <div class="dropdown-item p-3 border-bottom text-center arrow bg-white">
                            <img class="mb-2" src="/img/magic.svg" width="48" height="48" alt="">
                            <p class="fs-6 fw-bold">主页优先显示热门帖子</p>
                        </div>
                        <a class="dropdown-item" href="#">
                            <i class="iconfont icon-exchange me-2"></i>
                            <span>切换查看最新帖子</span>
                        </a>
                        <a class="dropdown-item" href="#">
                            <i class="iconfont icon-set me-2"></i>
                            <span>查看内容偏好设置</span>
                        </a>
                    </div>
                </div>
            </div>

            <!-- 发帖框 -->
            <?php if(session('user_id')): ?>
<div class="composer d-flex px-3 py-12px" id="homeEditor">
    <a href="/user/profile/<?php echo session('user_id'); ?>" class="position-relative">
        <img class="avatar" src="<?php echo get_avatar(session('user_id')); ?>" alt="">
    </a>
    <div class="flex-fill">
        <form id="post-form" class="needs-validation" method="POST" enctype="multipart/form-data" novalidate>
            <textarea class="form-control border-0 px-0 js-textarea" name="content" id="content" maxlength="200"
                spellcheck="false" placeholder="有什么新鲜事儿？" required autofocus></textarea>
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
            <input type="file" class="d-none" name="imageUpload" id="imageUpload"
                accept=".jpeg, .jpg, .png, .gif, .wbep">
            <div class="composer-action d-flex justify-content-between align-items-center mb-2">
                <div class="dropdown">
    <button class="btn btn-icon btn-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false" title="表情">
        <i class="iconfont icon-smile fs-5 text-primary"></i>
    </button>
    <button class="btn btn-icon btn-sm" type="button" aria-expanded="false" title="图片">
        <label for="imageUpload" class="cursor-pointer">
            <i class="iconfont icon-image fs-5 text-primary"></i>
        </label>
    </button>
    <ul class="dropdown-menu shadow-sm emoji-list p-2" data-stoppropagation="true">
        <li onclick="h_editor.insert('❤', -1, true);">❤</li>
        <li onclick="h_editor.insert('❄', -1, true);">❄</li>
        <li onclick="h_editor.insert('⛄', -1, true);">⛄</li>
        <li onclick="h_editor.insert('🈚', -1, true);">🈚</li>
        <li onclick="h_editor.insert('🈶', -1, true);">🈶</li>
        <li onclick="h_editor.insert('😃', -1, true);">😃</li>
        <li onclick="h_editor.insert('😅', -1, true);">😅</li>
        <li onclick="h_editor.insert('😉', -1, true);">😉</li>
        <li onclick="h_editor.insert('😍', -1, true);">😍</li>
        <li onclick="h_editor.insert('😝', -1, true);">😝</li>
        <li onclick="h_editor.insert('😏', -1, true);">😏</li>
        <li onclick="h_editor.insert('😒', -1, true);">😒</li>
        <li onclick="h_editor.insert('😞', -1, true);">😞</li>
        <li onclick="h_editor.insert('😔', -1, true);">😔</li>
        <li onclick="h_editor.insert('😓', -1, true);">😓</li>
        <li onclick="h_editor.insert('💩', -1, true);">💩</li>
        <li onclick="h_editor.insert('👐', -1, true);">👐</li>
        <li onclick="h_editor.insert('👊', -1, true);">👊</li>
        <li onclick="h_editor.insert('🙈', -1, true);">🙈</li>
        <li onclick="h_editor.insert('⚽', -1, true);">⚽</li>
    </ul>
</div>

<script>
    let h_editor;
    document.addEventListener('DOMContentLoaded', () => {
        // 检查 TE 是否已经定义
        if (typeof TextEditor === 'undefined') {
            console.warn('TE 没有定义，无法初始化编辑器。');
            return;
        }

        // 获取所有的 textarea 元素并选择第一个（如果存在）
        const textareas = document.querySelectorAll('textarea');
        if (!textareas) {
            console.warn('没有找到任何 textarea 元素来初始化编辑器。');
            return;
        }

        // 使用找到的 textarea 元素初始化编辑器
        try {
            h_editor = new TextEditor(textareas[0]);
        } catch (error) {
            console.error('初始化编辑器时发生错误：', error);
            // 这里可以添加额外的错误处理逻辑，比如显示一个错误提示给用户
        }
    });
</script>
                <div>
                    <!-- <span class="textarea-count" id="counter">200</span> -->
                    <?php if(isset($user) && $user !== null): if(isset($user['golds']) && $user['golds'] <= 0): ?>
                        <button type="button" class="btn btn-primary rounded-pill ms-auto fw-bold" disabled>金币不足</button>
                    <?php else: ?>
                        <button type="button" id="submitButton" class="btn btn-primary fw-bold rounded-pill" disabled>发布</button>
                        <!-- <button type="submit" class="btn btn-primary px-3 fw-bold rounded-pill">发布</button> -->
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </form>
        <div id="imageContainer"></div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const textarea = document.getElementById('content');
        const submitButton = document.getElementById('submitButton');

        document.getElementById('imageUpload').addEventListener('change', function (event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    const base64Image = e.target.result;

                    // 创建图片容器
                    const previewContainer = document.createElement('div');
                    previewContainer.classList.add('preview-container');

                    // 动态创建 <img> 元素
                    const img = document.createElement('img');
                    img.src = base64Image;
                    img.alt = "Image Preview";
                    img.classList.add('preview-image');

                    // 动态创建删除图标
                    const deleteIcon = document.createElement('i');
                    deleteIcon.classList.add('iconfont', 'icon-close', 'delete-icon');

                    // 为删除图标添加点击事件
                    deleteIcon.addEventListener('click', function () {
                        // 移除图片容器
                        const imageContainer = document.getElementById('imageContainer');
                        imageContainer.removeChild(previewContainer);

                        // 清空 textarea
                        const textArea = document.getElementById('textArea');
                        textArea.value = '';

                        // 清空文件输入框
                        const fileInput = document.getElementById('imageUpload');
                        fileInput.value = '';
                    });

                    // 将图片和删除图标添加到容器中
                    previewContainer.appendChild(img);
                    previewContainer.appendChild(deleteIcon);

                    // 插入到页面中
                    const imageContainer = document.getElementById('imageContainer');
                    imageContainer.innerHTML = ''; // 清空之前的图片
                    imageContainer.appendChild(previewContainer);

                    // 将 Base64 数据插入到 textarea 中
                    const textArea = document.getElementById('textArea');
                    textArea.value = base64Image;
                };
                reader.readAsDataURL(file);
            }
        });

        // 监听textarea的输入事件
        textarea.addEventListener('input', function () {
            // 如果textarea中有内容，启用按钮；否则禁用按钮
            if (textarea.value.trim() !== '') {
                submitButton.disabled = false;
            } else {
                submitButton.disabled = true;
            }
        });

        // 验证发帖内容
        function validateContent() {
            const content = document.getElementById('content').value.trim();
            return content.length > 0;
        }

        // 点击发帖按钮后验证
        if (submitButton) {
            submitButton.addEventListener('click', function () {
                if (!validateContent()) {
                    return toast('请输入帖子内容');
                }
                let data = new FormData(document.getElementById('post-form'));
                fetch('/post/submit', {
                    method: 'POST',
                    body: data
                })
                    .then(response => response.json())
                    .then(res => {
                        if (res.status === 'success') {
                            // 显示成功消息
                            toast(res.message);
                            setTimeout(() => {
                                location.reload();
                            }, 1500);
                        } else {
                            // 显示错误消息
                            toast(res.message);
                        }
                    })
                    .catch(error => {
                        toast('发帖失败');
                    });
            });
        }
    });
</script>
<?php endif; ?>
            <!-- 帖子列表 -->
            <ul class="feed-list list-unstyled">
    <?php if(!$posts): ?>
    <div class="empty-text fs-3">空空如也</div>
    <?php else: foreach($posts[0] as $post): ?>
    <li class="feed-item d-flex js-tap" id="feed<?php echo htmlentities((string) $post['id']); ?>" data-href="/post/show/<?php echo htmlentities((string) $post['id']); ?>" data-pid="<?php echo htmlentities((string) $post['id']); ?>">
        <a href="/user/profile/<?php echo htmlentities((string) $post['user_id']); ?>" class="position-relative">
            <img class="avatar lazyload" src="<?php echo get_avatar($post['user_id']); ?>" loading="lazy" alt="">
            <?php if($post['is_sticky']): ?>
            <div class="avatar-badge bg-danger">
                <i class="iconfont icon-thumbtack text-white"></i>
            </div>
            <?php endif; ?>
        </a>
        <div class="d-flex flex-column w-100">
            <div class="d-flex position-relative">
                <a class="feed-item-link fw-bold" href="/user/profile/<?php echo htmlentities((string) $post['user_id']); ?>"><?php echo htmlentities((string) $post['username']); ?></a>
                <a class="link-secondary ms-2" href="/post/show/<?php echo htmlentities((string) $post['id']); ?>"><?php echo nice_time($post['created_at']); ?></a>
                <div class="ms-auto dropdown">
                    <button class="btn btn-sm btn-icon feed-item-action" type="button" data-bs-toggle="dropdown"
                        aria-expanded="false"><i class="iconfont icon-more fs-18px"></i></button>
                    <div class="dropdown-menu dropdown-menu-end fs-15px">
                        <a class="dropdown-item" href="#">
                            <i class="iconfont icon-shield me-2"></i>
                            <span class="fw-bold">屏蔽</span>
                        </a>
                        <a class="dropdown-item" href="#">
                            <i class="iconfont icon-report me-2"></i>
                            <span class="fw-bold">举报 帖子</span>
                        </a>
                    </div>
                </div>
            </div>
            <p class="typo-text mt-1 fs-6"><?php echo $post['content']; ?></p>
            <!-- 图片附件 -->
            <?php echo generate_image_html($post); ?>
            <div class="mt-1 d-flex justify-content-between post-actions">
                <!-- 回复 -->
                <a role="button" class="post-action-reply cursor-arrow" title="回复">
                    <div class="btn btn-sm btn-icon post-action-icon">
                        <i class="iconfont icon-comment fs-18px js-no-click"></i>
                        <span class="badge fs-13px"><?php echo !empty($post['comments']) ? htmlentities((string) $post['comments']) : ''; ?></span>
                    </div>
                </a>

                <!-- 转帖 -->
                <a href="javascript:;" class="post-action-retweet cursor-default" title="转帖">
                    <div class="btn btn-sm btn-icon post-action-icon">
                        <i class="iconfont icon-retweet fs-18px js-no-click"></i>
                        <span class="badge fs-13px"><?php echo !empty($post['comments']) ? htmlentities((string) $post['comments']) : ''; ?></span>
                    </div>
                </a>

                <!-- 喜欢 -->
                <a href="javascript:;" class="post-action-like cursor-default" title="赞">
                    <div class="btn btn-sm btn-icon post-action-icon">
                        <i class="iconfont icon-thumbs-up fs-18px js-no-click"></i>
                        <span class="badge fs-13px"><?php echo !empty($post['likes']) ? htmlentities((string) $post['likes']) : ''; ?></span>
                    </div>
                </a>

                <!-- 收藏 -->
                <a href="javascript:;" class="post-action-fav cursor-default" title="收藏">
                    <div class="btn btn-sm btn-icon post-action-icon">
                        <i class="iconfont icon-fav fs-18px js-no-click"></i>
                        <span class="badge fs-13px"><?php echo !empty($post['favorites']) ? htmlentities((string) $post['favorites']) : ''; ?></span>
                    </div>
                </a>
            </div>
        </div>
    </li>
    <?php endforeach; ?>
    <?php endif; ?>
</ul>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        // 点击小图显示大图
        document.querySelectorAll('.feed-gallery').forEach(container => {
            const thumbnail = container.querySelector('.feed-item-img');

            thumbnail.addEventListener('click', () => {
                const overlay = document.createElement('div');
                overlay.className = 'loading-overlay';
                overlay.innerHTML = `
                        <div class="spinner-border text-light" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>`;
                container.appendChild(overlay);
                overlay.classList.add('visible');

                const tempImg = new Image();
                tempImg.src = thumbnail.dataset.large;

                tempImg.onload = () => {
                    [thumbnail.src, thumbnail.dataset.large] = [thumbnail.dataset.large, thumbnail.src];
                    thumbnail.classList.toggle('img-small');
                    thumbnail.classList.toggle('img-large');
                    overlay.remove();
                };

                tempImg.onerror = () => {
                    overlay.textContent = '加载失败';
                    setTimeout(() => overlay.remove(), 2000);
                };

                // 计算图片距离页面顶部的距离
                const imageTop = thumbnail.getBoundingClientRect().top + window.pageYOffset;
                // 计算目标滚动位置（图片顶部 - 120px）
                const targetPosition = imageTop - 120;
                // 滚动到目标位置
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth' // 平滑滚动
                });
            });
        });
    });
</script>
            <!-- 分页 -->
            <?php echo render_pagination($posts[1]); ?>

        </div>
        <div class="sidebar-col">
            <div class="position-sticky sidebar-sticky">
                <div class="position-relative mt-2 mb-3">
                    <i class="iconfont icon-search search-iconfont"></i>
                    <input class="form-control rounded-5 search-input" type="text" placeholder="搜索">
                </div>
                <div class="tile mb-3">
                    <h2 class="mb-0 py-12px px-3 fs-6 fw-bold">每日帖不过３😉</h2>
                    <div class="px-3 pb-3">
                        <p class="mt-1 mb-3 fs-15px">友情提示，发帖和回帖都需要<i class="squiggle">扣除１枚金币</i>哦！</p>
                        <a class="btn btn-dark rounded-pill" href="/reward">领取今日登录奖励</a>
                    </div>
                </div>
                <div class="tile">
                    <h2 class="mb-0 py-12px px-3 fs-6 fw-bold">有什么新鲜事？</h2>
                    <div href="###" class="tile-item d-flex">
                        <img src="/img/avatar.jpg" width="60" height="60" alt="">
                        <div class="d-flex flex-column">
                            <div class="fw-bold">摔跤大赛是真打吗？</div>
                            <div class="fs-13px text-muted">摔角 . 昨天</div>
                        </div>
                    </div>
                    <div class="tile-item d-flex flex-column">
                        <div class="fs-13px text-muted">科幻</div>
                        <div>测试标题，测试标题，test</div>
                        <div class="fs-13px text-muted"><i class="iconfont icon-analytics"></i> 114</div>
                    </div>
                    <a class="d-flex p-3 tile-footer" href="###">更多</a>
                </div>
            </div>
        </div>
    </div>
</main>


    <script src="/js/jquery.min.js"></script>
    <script src="/js/bootstrap.bundle.min.js"></script>
    <script src="/js/editor429.js"></script>
    <script src="/js/twitter.js"></script>
    <script src="/js/gifffer.min.js"></script>
    
<script>
    document.addEventListener("DOMContentLoaded", () => {
        // 当前链接添加 active
        highlightActiveLink("home");
        // 切换当前链接的 iconfont
        updateIconClassOnActive('.app-link', 'icon-home', 'icon-home-fill');
    });
</script>

    <script>
        window.addEventListener('load', function () {
            // GIF动画播放
            Gifffer();
        });
    </script>
</body>

</html>