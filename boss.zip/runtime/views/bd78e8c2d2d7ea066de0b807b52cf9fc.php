<?php /*a:1:{s:44:"/www/wwwroot/boss/app/view/layout/_jump.html";i:1738493644;}*/ ?>
<!doctype html>
<html lang="zh-cn">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>跳转提示</title>
    <style>
        body {
            margin: 0;
            font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", "Noto Sans", "Liberation Sans", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            font-size: 1.125rem;
            line-height: 1.5;
            color: #212529;
            text-align: center;
            background-color: #fff;
        }

        .jump {
            padding: 7rem 1rem 1rem 1rem;
        }

        .squiggle {
            -webkit-text-decoration: underline wavy #dc3545;
            text-decoration: underline wavy #dc3545;
            -webkit-text-decoration-skip-ink: none;
            text-decoration-skip-ink: none;
            text-underline-offset: 0.25em;
        }

        .btn {
            min-width: 5rem;
            display: inline-block;
            padding: .75rem 1rem;
            font-size: 1rem;
            color: #fff;
            background-color: #393939;
            border-radius: 4rem;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
            text-decoration: none;
            transition: color .15s ease-in-out, background-color .15s ease-in-out, box-shadow .15s ease-in-out
        }
        .btn:hover {
            background-color: #474747;
        }

        .btn-danger {
            background-color: #da1e28;
        }

        .btn-danger:hover {
            background-color: #b81921;
        }
    </style>
</head>

<body>
    <div class="jump">
        <img src="/img/firewall.png" alt="防火墙图标">
        <p><b>即将访问其他网站，请注意账号财产安全。</b></p>
        <p class="squiggle"><?php echo htmlentities((string) $target); ?></p>
        <p>
            <a href="javascript:;" id="js-back" class="btn" role="button">返回</a>
            <a href="<?php echo htmlentities((string) $target); ?>" class="btn btn-danger" role="button">继续访问</a>
        </p>
    </div>
    <script>
        const backButton = document.getElementById('js-back');
        backButton.addEventListener('click', function(event) {
            event.preventDefault();

            // 检查来源网址并决定回退或重定向到首页
            if (document.referrer === "") {
                window.location.href = "/";
            } else {
                window.history.back();
            }
        });
    </script>
</body>

</html>