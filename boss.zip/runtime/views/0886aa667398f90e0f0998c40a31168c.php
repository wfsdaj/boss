<?php /*a:5:{s:41:"/www/wwwroot/boss/app/view/post/show.html";i:1738493644;s:42:"/www/wwwroot/boss/app/view/layout/app.html";i:1738457294;s:45:"/www/wwwroot/boss/app/view/layout/header.html";i:1738457294;s:44:"/www/wwwroot/boss/app/view/layout/_like.html";i:1738493644;s:47:"/www/wwwroot/boss/app/view/layout/_comment.html";i:1737906477;}*/ ?>
<!doctype html>
<html lang="zh-cn">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlentities((string) $post['username']); ?>: <?php echo htmlentities((string) $post['content']); ?></title>
    <link rel="stylesheet" href="/font/iconfont.css">
    <link rel="stylesheet" href="/css/bootstrap.css">
    <link rel="stylesheet" href="/css/twitter.css">
</head>

<body class="d-flex w-100">
    <header id="app-header" class="flex-column flex-grow-1 align-items-end" role="banner">
    <div class="header-wrap d-flex align-items-end">
        <div class="header-wrap d-flex flex-column px-2 position-fixed top-0 h-100 overflow-x-hidden overflow-y-auto">
            <div class="d-flex flex-column">
                <h1 class="app-logo p-3 mb-0" role="heading">
                    <a href="/"><img src="/img/logo.png" loading="lazy" alt=""></a>
                </h1>
                <nav class="app-nav d-flex flex-column" role="navigation">
                    <a href="/" class="app-link" data-active="home" title="主页">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-home"></i>
                            <div class="app-nav-text">主页</div>
                            <div class="unread-dot"></div>
                        </div>
                    </a>
                    <a class="app-link" href="/explore" data-active="explore" title="探索">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-search"></i>
                            <div class="app-nav-text">探索</div>
                        </div>
                    </a>
                    <a class="app-link" href="/notification" data-active="notifications" title="通知">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-notifications"></i>
                            <div class="app-nav-text">通知</div>
                            <div class="d-flex align-items-center unread-message ">1</div>
                        </div>
                    </a>
                    <a class="app-link" href="/message" data-active="message" title="私信">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-messages"></i>
                            <div class="app-nav-text">私信</div>
                        </div>
                    </a>
                    <a href="/fav" class="app-link" data-active="fav" title="收藏夹">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-fav"></i>
                            <div class="app-nav-text">收藏夹</div>
                        </div>
                    </a>
                    <!-- <a href="/tag" class="app-link" data-active="tag" title="标签">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-explore"></i>
                            <div class="app-nav-text">标签</div>
                        </div>
                    </a>
                    <a class="app-link" href="/reward" data-active="reward" title="奖励">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-present"></i>
                            <div class="app-nav-text">领金币</div>
                        </div>
                    </a>
                    <a class="app-link" href="/medal" data-active="medal" title="勋章">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-medal"></i>
                            <div class="app-nav-text">勋章</div>
                        </div>
                    </a>
                    <a class="app-link" href="/tool" data-active="tool" title="工具箱">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-work"></i>
                            <div class="app-nav-text">工具箱</div>
                        </div>
                    </a>
                    <a class="app-link" href="/lists" data-active="lists" title="列表">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-lists"></i>
                            <div class="app-nav-text">列表</div>
                        </div>
                    </a>
                    <a class="app-link" href="/message" data-active="message" title="消息">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-notifications"></i>
                            <div class="app-nav-text">消息</div>
                            <div class="unread-message">1</div>
                        </div>
                    </a>
                    <a class="app-link" href="/bbs" data-active="bbs" title="动态">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-topics"></i>
                            <div class="app-nav-text">动态</div>
                        </div>
                    </a> -->
                    <?php if(session('user_id')): ?>
                    <a class="app-link" href="/user/profile/<?php echo session('user_id'); ?>" data-active="user" title="个人资料">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-user"></i>
                            <div class="app-nav-text">个人资料</div>
                        </div>
                    </a>
                    <button type="button" id="createPost" class="btn btn-dark justify-content-center rounded-pill" data-bs-toggle="modal" data-bs-target="#js-createPostModal">发帖</button>
                    <!-- 小屏显示的发帖按钮 -->
                    <button type="button" class="btn btn-dark twteet-btn" data-bs-toggle="modal" data-bs-target="#js-createPostModal" title="发帖">
                        <div class="nav-item d-inline-flex justify-content-center">
                            <i class="iconfont icon-feather"></i>
                        </div>
                    </button>
                    <?php else: ?>
                    <a class="app-link" href="/login" data-active="user" title="登录">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-user"></i>
                            <div class="app-nav-text">登录</div>
                        </div>
                    </a>
                    <?php endif; ?>
                </nav>
            </div>
            <?php if(session('user_id')): ?>
            <div class="dropup mt-auto">
                <div class="d-flex align-items-center fs-15px account-switcher-btn" id="account-switcher-btn" data-bs-toggle="dropdown" aria-expanded="false">
                    <img class="avatar" src="<?php echo get_avatar(session('user_id')); ?>" loading="lazy" alt="">
                    <div class="d-flex flex-column lh-1 ms-2">
                        <div><?php echo session('username'); ?></div>
                    </div>
                    <div class="ms-auto">
                        <i class="iconfont icon-more fs-5"></i>
                    </div>
                </div>
                <div class="dropdown-menu">
                    <?php if(session('is_admin')): ?>
                    <a href="/admin" class="dropdown-item">
                        <i class="iconfont icon-set fs-5 me-2"></i>
                        <span>进入后台</span>
                    </a>
                    <hr class="dropdown-divider">
                    <?php endif; ?>
                    <a href="/auth/logout/<?php echo csrf_token(); ?>" class="dropdown-item">
                        <i class="iconfont icon-logout fs-5 me-2"></i>
                        <span>退出</span>
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</header>

<?php if(session('user_id')): ?>
<div class="modal fade" id="js-createPostModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-bottom-0">
                <h5 class="modal-title">发新帖</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Modal body text goes here.</p>
            </div>
            <div class="modal-footer border-top-0">
                <button type="button" class="btn btn-primary">发布</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

    
<main role="main" class="d-flex flex-grow-1">
    <div class="d-flex main-wrap justify-content-between min-vh-100">
        <!-- 中间内容列 -->
        <div class="primary-col">
            <!-- 顶部导航条 -->
            <div class="breadcrumb d-flex align-items-center px-3 js-scroll">
                <div class="btn btn-sm btn-icon me-3 js-back" aria-label="返回" role="button" tabindex="0">
                    <i class="iconfont icon-left-arrow fs-5"></i>
                </div>
                <h2 class="flex-fill fs-18px fw-bold cursor-pointer js-top">帖子</h2>
            </div>

            <!-- 帖子 -->
            <div class="article">
                <!-- 头像 -->
                <div class="d-flex align-items-center mt-2 px-3">
                    <a href="/user/profile/<?php echo htmlentities((string) $post['user_id']); ?>">
                        <img class="avatar" src="<?php echo get_avatar($post['user_id']); ?>" alt="">
                    </a>
                    <p class="ps-12px fw-bold"><?php echo htmlentities((string) $post['username']); ?></p>
                    <div class="ms-auto">
                        <button class="btn btn-sm btn-danger rounded-pill">关注</button>
                    </div>
                </div>
                <!-- 帖子内容 -->
                <div class="p-3">
                    <div class="typo-text fs-18px" id="postContent"><?php echo $post['content']; ?></div>
                    <?php if($post['images'] > 0): ?>
                    <div class="feed-gallery mt-2">
                        <img class="img-fluid" src="/upload/<?php echo htmlentities((string) $post['filename']); ?>" alt="">
                    </div>
                    <?php endif; ?>
                </div>
                <div class="d-flex align-items-center px-3 pb-2 fs-14px text-muted border-bottom">
                    <span class="d-inline-block me-3">
                        <time datetime="<?php echo htmlentities((string) date('Y-m-d H:i:s',!is_numeric($post['created_at'])? strtotime($post['created_at']) : $post['created_at'])); ?>"><?php echo nice_time($post['created_at']); ?>前 ·
                            <?php echo htmlentities((string) date('Y-m-d',!is_numeric($post['created_at'])? strtotime($post['created_at']) : $post['created_at'])); ?></time>
                    </span>
                    <!-- <span class="d-inline-block me-3">山东</span> -->
                    <!-- 帖子工具栏 -->
                    <div class="dropdown ms-auto">
                        <button class="btn btn-sm btn-icon" type="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <i class="iconfont icon-more fs-5"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end">
                            <?php if(is_admin()): ?>
                            <a href="javascript:;" class="dropdown-item" id="js-pin" role="button"
                                data-post-id="<?php echo htmlentities((string) $post['id']); ?>">
                                <i class="iconfont icon-thumbtack me-2"></i>
                                <?php if($post['is_sticky']): ?>
                                <span class="fw-bold">取消置顶</span>
                                <?php else: ?>
                                <span class="fw-bold">置顶</span>
                                <?php endif; ?>
                            </a>
                            <?php endif; if(is_admin() || is_author($post['user_id'])): ?>
                            <a href="javascript:;" class="dropdown-item text-danger" id="js-del"
                                data-post-id="<?php echo segment(3); ?>">
                                <i class="iconfont icon-trash me-2"></i>
                                <span>删除</span>
                            </a>
                            <?php endif; ?>
                            <a class="dropdown-item" href="#">
                                <i class="iconfont icon-shield me-2"></i>
                                <span>屏蔽</span>
                            </a>
                            <a class="dropdown-item" href="#">
                                <i class="iconfont icon-report me-2"></i>
                                <span>举报 帖子</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-between py-1 px-3 ms-0 post-actions border-bottom">
                    <!-- 评论数 -->
                    <a role="button" class="post-action-reply cursor-arrow" data-bs-toggle="tooltip"
                        data-bs-trigger="hover" title="评论">
                        <div class="btn btn-sm btn-icon post-action-icon">
                            <i class="iconfont icon-comment fs-18px"></i>
                            <span class="badge fs-13px"><?php echo !empty($post['comments']) ? htmlentities((string) $post['comments']) : ''; ?></span>
                        </div>
                    </a>
                    <!-- 转帖 -->
                    <a href="javascript:;" class="post-action-retweet cursor-default" title="转帖">
                        <div class="btn btn-sm btn-icon post-action-icon">
                            <i class="iconfont icon-retweet fs-18px js-no-click"></i>
                            <span class="badge fs-13px">5</span>
                        </div>
                    </a>

                    <!-- 喜欢 -->
                    <?php if(!is_logined()): ?>
<!-- 提醒登录 -->
<a href="javascript:;" class="post-action-like js-jump" data-bs-toggle="tooltip" data-bs-trigger="hover" title="喜欢">
    <div class="btn btn-sm btn-icon post-action-icon">
        <i class="iconfont icon-thumbs-up js-no-click"></i>
    </div>
    <span class="fs-13px"><?php echo !empty($post['likes']) ? htmlentities((string) $post['likes']) : ''; ?></span>
</a>
<?php endif; if(is_logined()): if($post['likes']): ?>
    <!-- 取消赞 -->
    <a href="javascript:;" class="post-action-like liked js-like" data-pid="<?php echo htmlentities((string) $post['id']); ?>" data-bs-toggle="tooltip" data-bs-trigger="hover" title="取消喜欢">
        <div class="btn btn-sm btn-icon post-action-icon">
            <i class="iconfont icon-thumbs-up-fill js-no-click"></i>
        </div>
        <span class="fs-13px js-likesNum<?php echo htmlentities((string) $post['id']); ?>"><?php echo htmlentities((string) $post['likes']); ?></span>
    </a>
    <?php else: ?>
    <!-- 点赞 -->
    <a href="javascript:;" class="post-action-like js-like" data-pid="<?php echo htmlentities((string) $post['id']); ?>" data-bs-toggle="tooltip" data-bs-trigger="hover" title="喜欢">
        <div class="btn btn-sm btn-icon post-action-icon">
            <i class="iconfont icon-thumbs-up js-no-click"></i>
        </div>
        <span class="fs-13px js-likesNum<?php echo htmlentities((string) $post['id']); ?>"></span>
    </a>
    <?php endif; ?>
<?php endif; ?>



                    <!-- <a href="javascript:;" class="post-action-like cursor-default" title="赞">
                        <div class="btn btn-sm btn-icon post-action-icon">
                            <i class="iconfont icon-thumbs-up fs-18px js-no-click"></i>
                            <span class="badge fs-13px">5</span>
                        </div>
                    </a> -->

                    <!-- 收藏 -->
                    <a href="javascript:;" class="post-action-fav cursor-default" title="收藏">
                        <div class="btn btn-sm btn-icon post-action-icon">
                            <i class="iconfont icon-fav fs-18px js-no-click"></i>
                            <span class="badge fs-13px">5</span>
                        </div>
                    </a>

                    <!-- 分享 -->
                    <a href="javascript:;" class="post-action-fav cursor-default" title="分享">
                        <div class="btn btn-sm btn-icon post-action-icon">
                            <i class="iconfont icon-upload fs-18px js-no-click"></i>
                            <span class="badge fs-13px">5</span>
                        </div>
                    </a>
                </div>
                <!-- <div>
                    㒭㒹㕛㚉㚐㚙㝍㠪㠭㤫㪳㫈㵘㶣㶪㸞㹜㽓㽒㿢丄丅冇卍叒叕囧壵夯夵嫑孒孧孨孬尕尛屮巭恏惢憇朤歪汖灮舙
                </div> -->
            </div>

            <!-- 评论框 -->
            <?php if(is_logined()): ?>
<div class="composer d-flex p-3 border-bottom js-elastic" id="jsCommentTextarea">
    <img class="avatar" src="<?php echo get_avatar(session('user_id')); ?>" alt="">
    <div class="flex-fill">
        <form id="commentForm" method="POST" action="/comment/submit">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
            <input type="hidden" name="post_id" id="post_id" value="<?php echo htmlentities((string) $post['id']); ?>">
            <textarea class="form-control p-3 mb-2 bg-light fs-6 lh-1 js-textarea" name="commentTextarea"
                id="commentTextarea" maxlength="200" spellcheck="false" placeholder="说说您的想法" required></textarea>
            <div class="composer-action d-flex align-items-center mb-2">
                <div class="dropdown">
                    <button class="btn btn-icon btn-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false"
                        data-bs-toggle="tooltip" data-bs-title="表情">
                        <i class="iconfont icon-smile fs-5 text-primary"></i>
                    </button>
                    <!-- 表情 -->
                    <ul id="emojiList" class="dropdown-menu dropdown-menu-star shadow-sm emoji-list p-2" data-stoppropagation="true">
                        <li>❤</li><li>❄</li><li>⛄</li><li>🈚</li><li>🈶</li><li>😃</li><li>😅</li>
                        <li>😉</li><li>😍</li><li>😝</li><li>😏</li><li>😒</li><li>😞</li><li>😔</li>
                        <li>😓</li><li>💩</li><li>👐</li><li>👊</li><li>🙈</li><li>⚽</li>
                    </ul>
                </div>
                <?php if(isset($user) && $user !== null): if(isset($user['golds']) && $user['golds'] <= 0): ?>
                        <button type="button" class="btn btn-primary rounded-pill ms-auto fw-bold" disabled>金币不足</button>
                    <?php else: ?>
                    <button type="button" id="submitComments" class="btn btn-primary rounded-pill ms-auto fw-bold submitButton"
                        disabled>评论</button>
                    <!-- <button type="submit" class="btn btn-primary rounded-pill fw-bold submitButton" disabled>回帖</button> -->
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>
<?php else: ?>
<div class="p-4 text-center bg-light border-bottom">
    <h3 class="fs-18px fw-bold mb-2">您好！喜欢交流可以注册账号。</h3>
    <p class="mb-3 text-muted">拥有账号，您才可以回复用户的帖子。<br>您还可以收到新回复通知、收藏帖子，以及使用“赞”来感谢他人。</p>
    <a href="/login" class="btn btn-primary rounded-pill">登录</a>
    <a href="/register" class="btn btn-light rounded-pill ms-1">注册</a>
</div>
<?php endif; ?>

<script>
    // 回帖编辑器
    let comment_editor;

    window.addEventListener('load', function () {
        // 初始化回帖编辑器
        const commentTextarea = document.getElementById('commentTextarea');
        if (commentTextarea && typeof TextEditor === 'function') {
            comment_editor = new TextEditor(commentTextarea);
            // 表情列表
            const emojiList = document.getElementById('emojiList');
            if (emojiList) {
                emojiList.addEventListener('click', function (event) {
                    if (event.target.tagName === 'LI') {
                        const emoji = event.target.textContent;
                        comment_editor.insert(emoji, -1, true);
                    }
                });
            }
        }

        // 点击提交按钮后验证
        const submitCommentsElement = document.getElementById('submitComments');
        if (submitCommentsElement) {
            submitCommentsElement.addEventListener('click', function () {
                let form = document.getElementById('commentForm');
                let data = new FormData(form);

                // 发送 AJAX 请求
                fetch('/comment/submit', {
                    method: 'POST',
                    body: data,
                })
                    .then(response => response.json())
                    .then(res => {
                        if (res.status === 'success') {
                            // 显示成功消息
                            toast(res.message);
                            setTimeout(() => {
                                location.reload();
                            }, 1500);
                        } else {
                            // 显示错误消息
                            toast(res.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error:');
                    });
            });
        }
    });
</script>
            <!-- 评论列表 -->
            <div id="comment_list">
                <div class="text-center">
                    <div id="loadingSpinner" class="spinner-border m-5" role="status" style="display: none;">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- 边栏 -->
        <div class="sidebar-col">
            <div class="position-sticky sidebar-sticky">
                <div class="position-relative mt-2 mb-3">
                    <i class="iconfont icon-search search-iconfont"></i>
                    <input class="form-control rounded-5 search-input" type="text" placeholder="搜索">
                </div>
                <div class="tile">
                    <h2 class="mb-0 py-12px px-3 fs-18px fw-bold">有什么新鲜事？</h2>
                    <div href="###" class="tile-item d-flex">
                        <img src="/img/avatar.jpg" width="79" height="79" alt="">
                        <div class="d-flex flex-column">
                            <div class="fs-15 fw-bold">摔跤大赛是真打吗？</div>
                            <div class="fs-13 text-muted">摔角 . 昨天</div>
                        </div>
                    </div>
                    <div class="tile-item d-flex flex-column">
                        <div class="fs-13px text-muted">科幻</div>
                        <div class="fs-15px fw-bold">测试标题，测试标题，test</div>
                        <div class="fs-13px text-muted"><i class="iconfont icon-analytics"></i> 114</div>
                    </div>
                    <a class="d-flex p-3 tile-footer" href="###">更多</a>
                </div>
            </div>
        </div>
    </div>
</main>


    <script src="/js/jquery.min.js"></script>
    <script src="/js/bootstrap.bundle.min.js"></script>
    <script src="/js/editor429.js"></script>
    <script src="/js/twitter.js"></script>
    <script src="/js/gifffer.min.js"></script>
    
<script src="/js/post.js"></script>
<script src="/js/medium-zoom.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        mediumZoom('[data-zoomable]', {
            margin: 30,
            background: 'rgba(0,0,0,.7)',
        });

        // $('#loadingSpinner').show();
        $.ajax({
            url: `/comment/list/<?php echo htmlentities((string) $post_id); ?>`,
            type: 'GET',
            dataType: 'html',
            beforeSend: function () {
                // 请求开始前显示加载层
                $('#loadingSpinner').show();
            },
            success: function (data) {
                $('#loadingSpinner').hide();
                $('#comment_list').html(data);
            },
            error: function (xhr, status, error) {
                $('#loadingSpinner').hide();
                console.error('Error loading URL:', status, error);
                // toast('评论列表加载失败');
            }
        });

        const jDel = document.getElementById('js-del');

        if (jDel) {
            jDel.addEventListener('click', function () {
                let postId = this.getAttribute('data-post-id');
                fetch(`/post/del/${postId}`, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        'post_id': postId
                    })
                })
                    .then(response => response.json())
                    .then(res => {
                        if (res.status === 'success') {
                            toast(res.message, 'success');
                            setTimeout(function () {
                                window.location.href = "/";
                            }, 2000);
                        } else {
                            toast(res.message, 'danger');
                        }
                    })
                    .catch(error => console.error('Error:', error));
            });
        }
    });
</script>

    <script>
        window.addEventListener('load', function () {
            // GIF动画播放
            Gifffer();
        });
    </script>
</body>

</html>