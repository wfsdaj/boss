<?php /*a:1:{s:52:"/www/wwwroot/boss/app/view/layout/_comment_list.html";i:1738457294;}*/ ?>
<?php if($comments[1]->totalRows > 0): ?>
    <ul class="list-unstyled chat p-3 border-bottom">
    <?php foreach($comments[0] as $comment): if(!is_author($comment['user_id'])): ?>
        <li class="others">
            <div class="chat-item">
                <a href="/user/profile/<?php echo htmlentities((string) $comment['user_id']); ?>">
                    <img class="avatar me-2" src="<?php echo get_avatar($comment['user_id']); ?>" alt="">
                </a>
                <div>
                    <div class="chat-content"><?php echo htmlentities((string) $comment['content']); ?></div>
                    <span class="fs-13px text-muted"><?php echo htmlentities((string) $comment['username']); ?> · <?php echo nice_time($comment['created_at']); ?>前</span>
                </div>
            </div>
        </li>
        <?php else: ?>
        <li class="self">
            <div class="chat-item">
                <a href="/user/profile/<?php echo htmlentities((string) $comment['user_id']); ?>">
                    <img class="avatar ms-2" src="<?php echo get_avatar($comment['user_id']); ?>" alt="">
                </a>
                <div>
                    <div class="chat-content"><?php echo htmlentities((string) $comment['content']); ?></div>
                    <span class="fs-13px text-muted"><?php echo nice_time($comment['created_at']); ?>前 · <?php echo htmlentities((string) $comment['username']); ?></span>
                </div>
            </div>
        </li>
        <?php endif; ?>
    <?php endforeach; ?>
    </ul>
<?php else: ?>
    <div class="empty-text fs-5">暂无评论</div>
<?php endif; ?>