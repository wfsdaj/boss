<?php /*a:3:{s:44:"/www/wwwroot/boss/app/view/reward/index.html";i:1738457294;s:42:"/www/wwwroot/boss/app/view/layout/app.html";i:1738457294;s:45:"/www/wwwroot/boss/app/view/layout/header.html";i:1738457294;}*/ ?>
<!doctype html>
<html lang="zh-cn">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>奖励</title>
    <link rel="stylesheet" href="/font/iconfont.css">
    <link rel="stylesheet" href="/css/bootstrap.css">
    <link rel="stylesheet" href="/css/twitter.css">
</head>

<body class="d-flex w-100">
    <header id="app-header" class="flex-column flex-grow-1 align-items-end" role="banner">
    <div class="header-wrap d-flex align-items-end">
        <div class="header-wrap d-flex flex-column px-2 position-fixed top-0 h-100 overflow-x-hidden overflow-y-auto">
            <div class="d-flex flex-column">
                <h1 class="app-logo p-3 mb-0" role="heading">
                    <a href="/"><img src="/img/logo.png" loading="lazy" alt=""></a>
                </h1>
                <nav class="app-nav d-flex flex-column" role="navigation">
                    <a href="/" class="app-link" data-active="home" title="主页">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-home"></i>
                            <div class="app-nav-text">主页</div>
                            <div class="unread-dot"></div>
                        </div>
                    </a>
                    <a class="app-link" href="/explore" data-active="explore" title="探索">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-search"></i>
                            <div class="app-nav-text">探索</div>
                        </div>
                    </a>
                    <a class="app-link" href="/notification" data-active="notifications" title="通知">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-notifications"></i>
                            <div class="app-nav-text">通知</div>
                            <div class="d-flex align-items-center unread-message ">1</div>
                        </div>
                    </a>
                    <a class="app-link" href="/message" data-active="message" title="私信">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-messages"></i>
                            <div class="app-nav-text">私信</div>
                        </div>
                    </a>
                    <a href="/fav" class="app-link" data-active="fav" title="收藏夹">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-fav"></i>
                            <div class="app-nav-text">收藏夹</div>
                        </div>
                    </a>
                    <!-- <a href="/tag" class="app-link" data-active="tag" title="标签">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-explore"></i>
                            <div class="app-nav-text">标签</div>
                        </div>
                    </a>
                    <a class="app-link" href="/reward" data-active="reward" title="奖励">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-present"></i>
                            <div class="app-nav-text">领金币</div>
                        </div>
                    </a>
                    <a class="app-link" href="/medal" data-active="medal" title="勋章">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-medal"></i>
                            <div class="app-nav-text">勋章</div>
                        </div>
                    </a>
                    <a class="app-link" href="/tool" data-active="tool" title="工具箱">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-work"></i>
                            <div class="app-nav-text">工具箱</div>
                        </div>
                    </a>
                    <a class="app-link" href="/lists" data-active="lists" title="列表">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-lists"></i>
                            <div class="app-nav-text">列表</div>
                        </div>
                    </a>
                    <a class="app-link" href="/message" data-active="message" title="消息">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-notifications"></i>
                            <div class="app-nav-text">消息</div>
                            <div class="unread-message">1</div>
                        </div>
                    </a>
                    <a class="app-link" href="/bbs" data-active="bbs" title="动态">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-topics"></i>
                            <div class="app-nav-text">动态</div>
                        </div>
                    </a> -->
                    <?php if(session('user_id')): ?>
                    <a class="app-link" href="/user/profile/<?php echo session('user_id'); ?>" data-active="user" title="个人资料">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-user"></i>
                            <div class="app-nav-text">个人资料</div>
                        </div>
                    </a>
                    <button type="button" id="createPost" class="btn btn-dark justify-content-center rounded-pill" data-bs-toggle="modal" data-bs-target="#js-createPostModal">发帖</button>
                    <!-- 小屏显示的发帖按钮 -->
                    <button type="button" class="btn btn-dark twteet-btn" data-bs-toggle="modal" data-bs-target="#js-createPostModal" title="发帖">
                        <div class="nav-item d-inline-flex justify-content-center">
                            <i class="iconfont icon-feather"></i>
                        </div>
                    </button>
                    <?php else: ?>
                    <a class="app-link" href="/login" data-active="user" title="登录">
                        <div class="nav-item d-inline-flex">
                            <i class="iconfont icon-user"></i>
                            <div class="app-nav-text">登录</div>
                        </div>
                    </a>
                    <?php endif; ?>
                </nav>
            </div>
            <?php if(session('user_id')): ?>
            <div class="dropup mt-auto">
                <div class="d-flex align-items-center fs-15px account-switcher-btn" id="account-switcher-btn" data-bs-toggle="dropdown" aria-expanded="false">
                    <img class="avatar" src="<?php echo get_avatar(session('user_id')); ?>" loading="lazy" alt="">
                    <div class="d-flex flex-column lh-1 ms-2">
                        <div><?php echo session('username'); ?></div>
                    </div>
                    <div class="ms-auto">
                        <i class="iconfont icon-more fs-5"></i>
                    </div>
                </div>
                <div class="dropdown-menu">
                    <?php if(session('is_admin')): ?>
                    <a href="/admin" class="dropdown-item">
                        <i class="iconfont icon-set fs-5 me-2"></i>
                        <span>进入后台</span>
                    </a>
                    <hr class="dropdown-divider">
                    <?php endif; ?>
                    <a href="/auth/logout/<?php echo csrf_token(); ?>" class="dropdown-item">
                        <i class="iconfont icon-logout fs-5 me-2"></i>
                        <span>退出</span>
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</header>

<?php if(session('user_id')): ?>
<div class="modal fade" id="js-createPostModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-bottom-0">
                <h5 class="modal-title">发新帖</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Modal body text goes here.</p>
            </div>
            <div class="modal-footer border-top-0">
                <button type="button" class="btn btn-primary">发布</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

    
<main role="main" class="d-flex flex-grow-1">
    <div class="d-flex main-wrap justify-content-between min-vh-100">
        <div class="primary-col">
            <!-- 顶部导航条 -->
            <div class="breadcrumb d-flex justify-content-between align-items-center px-3 js-scroll">
                <a href="/login" class="btn btn-sm btn-icon only-on-sm" role="button">
                    <i class="iconfont icon-user"></i>
                </a>
                <h2 class="fs-18px fw-bold cursor-pointer w-100 js-top">奖励</h2>
            </div>
            <div class="d-flex justify-content-around p-4 text-muted fs-15 bg-light">
                <div>
                    <p class="fs-2 text-dark"><?php echo !empty($is_signed) ? '3'  :  '0'; ?></p>
                    <span>今日已领</span>
                </div>
                <div>
                    <p class="fs-2 text-dark"><?php echo !empty($last_signed_time) ? nice_time($last_signed_time)  :  '0'; ?></p>
                    <span>上次签到时间</span>
                </div>
                <div>
                    <p class="fs-2 text-dark"><?php echo htmlentities((string) (isset($golds) && ($golds !== '')?$golds:"-")); ?></p>
                    <span>可用积分</span>
                </div>
            </div>
            <div class="wave-bar mb-2">
                <svg viewBox="0 0 1152 73">
                    <path
                        d="M99.0331 0.252716C59.2655 0.284556 0 25.2197 0 25.2197V0.252716H99.0331C99.0585 0.252696 99.0839 0.252686 99.1093 0.252686C99.1538 0.252686 99.1982 0.252696 99.2427 0.252716H1152V73C1018.73 21.6667 957.818 24.4226 819.692 22.7693C672.54 21.008 573.085 73 427.919 73C308.414 73 218.068 0.307089 99.2427 0.252716H99.0331Z">
                    </path>
                </svg>
            </div>

            <nav class="nav justify-content-center">
                <a class="nav-link fs-18px" id="my-reward" href="/reward">赚积分</a>
                <a class="nav-link fs-18px cursor-not-allowed" id="my-redeem">兑换</a>
                <a class="nav-link fs-18px cursor-not-allowed" id="my-levels">等级</a>
            </nav>

            <div class="d-flex justify-content-around p-4 text-center">
                <div class="box bg-white p-4 border rounded-4 me-4 text-dark text-decoration-none">
                    <div class="placement fs-5 fw-bold">
                        <span class="point <?php echo !empty($is_signed) ? 'bg-success'  :  ''; ?>"></span> 3
                    </div>
                    <p><i class="iconfont icon-present fs-2 text-success"></i></p>
                    <h3 class="fs-18px fw-bold">登录奖励</h3>
                    <p class="fs-15 my-3">领取每日登录奖励，可用于发帖、回帖和下载附件。</p>
                    <?php if(isset($is_signed) && $is_signed): ?>
                    <button type="button" class="btn btn-dark rounded-pill" disabled>已领取</button>
                    <?php else: ?>
                    <button type="submit" class="btn btn-dark rounded-pill" id="<?php echo !empty($is_signed) ? ''  :  'js-sign'; ?>">点击领取</button>
                    <?php endif; ?>
                </div>
                <div class="box p-4 border rounded-4">
                    <p><i class="iconfont icon-redpacket fs-2 text-danger"></i></p>
                    <h3 class="fs-18px fw-bold">红包</h3>
                    <p class="fs-15 mt-3">模块正在制作，敬请期待。</p>
                </div>
            </div>
        </div>
        <div class="sidebar-col">
            <div class="position-sticky sidebar-sticky">
                <div class="tile">
                    <h2 class="mb-0 p-3 fs-6 fw-bold">登录奖励</h2>
                    <div class="p-3 pt-0">
                        <p>- 每24小时可领取一次，每次 +3 点积分。</p>
                        <p>- 发帖、回帖每次各 -1 点积分。</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>


    <script src="/js/jquery.min.js"></script>
    <script src="/js/bootstrap.bundle.min.js"></script>
    <script src="/js/editor429.js"></script>
    <script src="/js/twitter.js"></script>
    <script src="/js/gifffer.min.js"></script>
    
<script>
    document.addEventListener("DOMContentLoaded", (event) => {
        // 高亮当前链接
        highlightActiveLink('reward');
        document.getElementById('my-reward').classList.add('active');
        // 签到
        const signElement = document.getElementById("js-sign");
        if (signElement) {
            event.preventDefault(); // 阻止默认行为，比如链接跳转
            signElement.addEventListener('click', function () {
                fetch('/reward/sign/', { method: 'POST' })
                    .then(response => response.json())
                    .then(res => {
                        if (res.status === 'success') {
                            toast(res.message);
                            document.querySelector('.point').classList.add('bg-success');
                            // 禁用按钮并显示"已领取"文字
                            signElement.textContent = '已领取';
                            signElement.disabled = true;
                            // 1.5秒后刷新页面
                            setTimeout(() => location.reload(), 1500);
                        } else {
                            toast(res.message);
                        }
                    })
                    .catch(error => console.error(error)); // 处理错误，避免被忽略。
            });
        }
    });
</script>

    <script>
        window.addEventListener('load', function () {
            // GIF动画播放
            Gifffer();
        });
    </script>
</body>

</html>