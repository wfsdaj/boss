<?php /*a:1:{s:38:"/www/wwwroot/boss/app/view/home/a.html";i:1737851948;}*/ ?>
<form action="/home/b" method="post" enctype="multipart/form-data">
    <input type="file" name="file">
    <button type="submit">aa</button>
</form>